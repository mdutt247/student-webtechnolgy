function yetAnotherAlert(textToAlert) {
    alert(textToAlert);
}
yetAnotherAlert("This is the Second Example.");

