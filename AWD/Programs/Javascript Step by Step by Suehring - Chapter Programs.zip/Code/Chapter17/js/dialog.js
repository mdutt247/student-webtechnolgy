$(document).ready(function () {
	$('#dialog').dialog({
		resizable: false,
		modal: true,
		buttons: {
			"Confirm": function() {
				// Perform actions here based on 
				// receiving confirmation
				// Then close the dialog:
				$(this).dialog("close");
			},
			Cancel: function() {
				$(this).dialog("close");
			}
		}  //end buttons option
	});
});
