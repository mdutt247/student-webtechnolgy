$(document).ready(function () {
	$('#cal').datepicker({
		changeMonth: true,
        changeYear: true,
		minDate: "-0D",
		maxDate: "+1Y +1D"
	});
});
