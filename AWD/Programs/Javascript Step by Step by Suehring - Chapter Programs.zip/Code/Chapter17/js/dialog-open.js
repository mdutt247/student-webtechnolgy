$(document).ready(function () {
	$("#dialog").dialog({ autoOpen: false });
	$('#opener').on('click', function() {
		$("#dialog").dialog({
			resizable: false,
			modal: true
		}); //end dialog
		$("#dialog").dialog("open");
	});
});
