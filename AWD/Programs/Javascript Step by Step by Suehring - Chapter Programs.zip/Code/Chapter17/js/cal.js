$(document).ready(function () {
	$('#cal').datepicker();
});
