$(document).ready(function () {
	$('#cal').datepicker({
		changeMonth: true,
        changeYear: true,
		minDate: "-1M",
		maxDate: "+12M"
	});
});
