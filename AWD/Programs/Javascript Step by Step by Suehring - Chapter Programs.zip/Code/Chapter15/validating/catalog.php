<?php

if (!isset($_POST['quantity'])) {
	die(print "Fill in a quality, eh?");
}
else if (!is_numeric($_POST['quantity'])) {
	die(print "Only numeric values allowed.");
}
else {
	$quantity = $_POST['quantity'];
//	if ($quantity > 3) {
//		die(print "No more than 3 blades allowed");
//	}
	$price = 100;
	$total = $quantity * $price;
	print "Order total: $" . $total;
	exit;
}

?>
