$(document).ready(function() {
	$("#formexample").on("submit",function(event) {
		if ($("#city").val() != "Stevens Point") {
			$("#citydiv").css("font-weight","bold");
			$("#citydiv").css("border","1px solid black");
			event.preventDefault();
			return false;
		} else {
			return true;
		}
	});
});
