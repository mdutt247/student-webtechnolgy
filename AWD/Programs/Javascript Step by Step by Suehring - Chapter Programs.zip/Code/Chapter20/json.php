<?php

$states = array(
	"Wisconsin",
	"California",
	"Colorado",
	"Illinois",
	"Minnesota",
	"Oregon",
	"Washington",
	"New York",
	"New Jersey",
	"Nevada",
	"Alabama",
	"Tennessee",
	"Iowa",
	"Michigan"
);

print json_encode($states);

?>

