<?php
	define('SITE_URL', 'http://comp14:3000/ranjit/'); // server http url
	
	define('DB_SERVER', 'localhost'); // database server/host
	
	define('DB_USER', 'root'); // database username
	
	define('DB_PASS', ''); // database password
	
	define('DB_NAME', 'menu'); // database name

?>